/*
 * UART.h
 *
 *  Created on: Oct 29, 2025
 *      Author: Dallas.Owens
 */

#ifndef UART_H_
#define UART_H_


//typedef enum {
//	BAUD_115200,		// 0
//	BAUD_460800,		// 1
//
//	BAUD_COUNT			// 2
//} Baud_Rate_t;



#endif /* UART_H_ */
