/*
 * switches.c
 *
 *  Created on: Sep 21, 2025
 *      Author: Dallas.Owens
 */

#include "macros.h"
#include  "functions.h"
#include  "msp430.h"
#include "ports.h"
#include "switches.h"
#include <string.h>

extern volatile unsigned int time_change;
extern char msg[SMALL_RING_SIZE];

// VARIABLES
unsigned int okay_to_look_at_switch1;
unsigned int sw1_position;
unsigned int count_debounce_SW1;

unsigned int okay_to_look_at_switch2;
unsigned int sw2_position;
unsigned int count_debounce_SW2;

unsigned int SW1_pressed = 0;
unsigned int SW2_pressed = 0;

unsigned int goto_Start = 0;
unsigned char drive_enabled = 0;
unsigned char display_ADC_values = 0;

unsigned int baud_rate;
unsigned int baud_delay;
unsigned int pending_send = 0;

extern volatile unsigned char allow_comms;

// SWITCH PRESS OPERATIONS
void Switches_Process(void) 
{
	if (SW1_pressed) {
		SW1_pressed = 0;						// consume the event
		allow_comms = 0;
	}
	if (SW2_pressed) {
		SW2_pressed = 0;						// consume the event
		allow_comms = 0;
	}
}


//------------------------------------------------------------------------------
// Init Switches
//------------------------------------------------------------------------------
//void Init_Switches(void){
//    P4DIR &= ~SW1;
//    P4REN |= SW1;
//    P4OUT |= SW1;
//
//    P2DIR &= ~SW2;
//    P2REN |= SW2;
//    P2OUT |= SW2;
//
//    okay_to_look_at_switch1     = OKAY;
//    sw1_position                = RELEASED;
//    count_debounce_SW1          = DEBOUNCE_RESTART;
//
//    okay_to_look_at_switch2     = OKAY;
//    sw2_position                = RELEASED;
//    count_debounce_SW2          = DEBOUNCE_RESTART;
//}


