/*
 * UART.c
 *
 *  Created on: Oct 29, 2025
 *      Author: Dallas.Owens
 */


#include "msp430.h"
#include "timers.h"
#include "ports.h"
#include "macros.h"
#include "functions.h"
#include  <string.h>
#include "UART.h"


// DONT PRIME THE BUFFER!!!!

//#define BAUD_115200            (0)            // 115200 Baud Rate
//#define BAUD_460800            (1)            // 460800 Baud Rate

unsigned char BaudRate;


volatile char USB_Char_Rx[SMALL_RING_SIZE];		// USB Rx Ring Buffer

extern volatile unsigned char USB_Ring_Rx[SMALL_RING_SIZE];		// USB Rx Ring Buffer
extern volatile unsigned int usb_rx_wr;				// USB Rx Ring Buffer Write Index
extern volatile unsigned int usb_rx_rd;				// USB Rx Ring Buffer Read Index

char UART_ProcBuff[1][11];						// UART Process Buffer (10 chars + NULL)
unsigned int uart_char = 0;						// UART Process Buffer Character Index
//unsigned int uart_line = 0;					// UART Process Buffer Line Index (not used for HW8)

unsigned char process_buffer[PROCESS_BUFFER_SIZE];	// UART Transmit Process Buffer

extern volatile unsigned char iot_TX_buf[SMALL_RING_SIZE];
extern volatile unsigned int iot_tx;

volatile unsigned char UCA1_TX_Buffer[PROCESS_BUFFER_SIZE];		// UCA1 TX Buffer
volatile unsigned int tx_index;

unsigned char usb_tx_ring_wr;
unsigned char usb_tx_ring_rd;

//unsigned char usb_rx_ring_wr;
//unsigned char usb_rx_ring_rd;

extern volatile unsigned char IOT_2_PC[SMALL_RING_SIZE];
extern volatile unsigned int iot_rx_wr;
extern volatile unsigned char allow_comms;


void Init_IOT(void) {
	P3OUT |= IOT_EN;
}

//void IOT_Process(void) {               // Process IOT messages
//	int i;
//	unsigned int iot_rx_wr_temp;
//	iot_rx_wr_temp = iot_rx_wr;
//
//	if (iot_rx_wr_temp != iot_rx_rd) {    // Determine if IOT is available
//		IOT_Data[line][character] = IOT_Ring_Rx[iot_rx_rd++];
//
//		if (iot_rx_rd >= sizeof(IOT_Ring_Rx)) {
//			iot_rx_rd = BEGINNING;
//		}
//
//		if (IOT_Data[line][character] == 0x0A) {
//			character = 0;
//			line++;
//			if (line >= 4) {
//				line = 0;
//			}
//
//			nextline = line + 1;
//			if (nextline >= 4) {
//				nextline = 0;
//			}
//
//		}
//		else {
//			switch (character) {
//			case  0:
//				if (IOT_Data[line][character] == '+') {   // Got "+"
//					test_Value++;
//					if (test_Value) {
//						RED_LED_ON;
//					}
//					IOT_parse = 1;
//				}
//				break;
//
//			case  1:
//				// GRN_LED_ON;
//				break;
//
//			case  4:
//				if (IOT_Data[line][character] == 'y') {   // Got read"y"
//					for (i = 0; i < sizeof(AT); i++) {
//						iot_TX_buf[i] = AT[i];
//					}
//					UCA0IE |= UCTXIE;
//					boot_state = 1;
//					// RED_LED_ON;
//					GRN_LED_OFF;
//				}
//				break;
//			case  5:
//				if (IOT_Data[line][character] == 'G') {      // Got IP
//					for (i = 0; i < sizeof(ip_mac); i++) {
//						iot_TX_buf[i] = ip_mac[i];
//					}
//					iot_tx = 0;
//					UCA0IE |= UCTXIE;
//				}
//				break;
//
//			case  6:
//
//				break;
//
//			case  10:
//				if (IOT_Data[line][character] == 'I') {
//					ip_address_found = 1;
//					strcpy(display_line[0], "IP Address");
//					for (i = 0; i < sizeof(ip_address); i++) {
//						ip_address[i] = 0;
//					}
//					display_changed = 1;
//					iot_index = 0;
//				}
//
//				break;
//			default: break;
//			}
//		}
//	}
//}


void UART_Process(void) {    // Process UART messages for LCD display
	unsigned int i;
	static char prev_char = '\0';
	unsigned int usb_rx_wr_temp;

	usb_rx_wr_temp = usb_rx_wr;

	if (usb_rx_wr_temp != usb_rx_rd)							// Determine if UART data is waiting
	{
		char current_char = USB_Ring_Rx[usb_rx_rd++];
		//current_char = usb_received;

		if (usb_rx_rd >= sizeof(USB_Ring_Rx))
		{
			usb_rx_rd = BEGINNING;
		}

		// EOL on CR, or LF that wasn't part of CRLF (chars already beuffered)
		if (current_char == '\r' || (current_char == '\n' && prev_char != '\r')) {
			if (uart_char > 0) {									// have something buffered?
				UART_ProcBuff[0][uart_char] = '\0';					// ensure last char is a null terminator (uart_char already inc'd past message chars below)
				strcpy(display_line[0], "          ");              // clear LCD line 1 (10 white-spaces)
				strncpy(display_line[0], UART_ProcBuff[0], 10);     // copy up to LCD line-width
				display_line[0][10] = '\0';							// terminate with ending NULL
				display_changed = TRUE;								// trigger lcd update
			}
			for (i = 0; i < 11; i++) {
				UART_ProcBuff[0][i] = '\0';							// clear processed buffer (10 + NUL)
			}
			uart_char = 0;										// reset cursor
			// uart_line = 0;									// reset to line 0 (only using 1 line for HW8, uncomment if robustifying with array of buffers)
		}
		else if (current_char != '\r' && current_char != '\n') {					// Don't store EOL detection bits
			if (uart_char < 10) {								// Stop pasting chars on overflow
				UART_ProcBuff[0][uart_char++] = current_char;		// No overflow -> update buffer
			}
			else {											// Overflow detected
				// add something here to deal with overflow [>10] chars if necessary
			}
		}

		prev_char = current_char;              // remember for CRLF detection
	}
}





void display_rx(char line, char location) {
	int i;
	unsigned int real_line;

	real_line = line - 1;
	for (i = 0; i < 10; i++) {
		display_line[real_line][location + i] = USB_Char_Rx[i];
	}
}
                   

void A0_transmit(void) {
    unsigned int i = 0;
	// Contents must be in process_buffer
	// End of Transmission is identified by NULL character in process_buffer
	// process_buffer includes Carriage Return and Line Feed
	while (process_buffer[i] != '\0') {
		iot_TX_buf[i] = process_buffer[i++];
		if (i >= sizeof(iot_TX_buf)) {
			break;				// Prevent buffer overflow
		}
		if (i < sizeof(iot_TX_buf)) {
			iot_TX_buf[i] = '\0';	// Null terminate the buffer
		}
		else {
			iot_TX_buf[sizeof(iot_TX_buf) - 1] = '\0';	// Ensure buffer is null terminated
		}
	}
	iot_tx = BEGINNING;				// Set Array index to first location
	UCA0IE |= UCTXIE;		// Enable TX interrupt
}

void A1_transmit(const char SEND_BUFFER[PROCESS_BUFFER_SIZE])
{ // Populate UCA1 TX Buffer and enable TX interrupt for transmitting
  //	- SEND_BUFFER holds message to transmit (must be null terminated)
  //    - UCA1_TX_Buffer volatile is populated from SEND_BUFFER - Ref'd in interrupt
	unsigned char A1_tx_char = 0;
	if (!SEND_BUFFER) { return; }

	while ((SEND_BUFFER[A1_tx_char] != 0) && (A1_tx_char < sizeof(UCA1_TX_Buffer) - 1)) {
		UCA1_TX_Buffer[A1_tx_char] = SEND_BUFFER[A1_tx_char++];
	}
	UCA1_TX_Buffer[A1_tx_char] = '\0';
	tx_index = BEGINNING;
	UCA1IE |= UCTXIE;
}


void A1_TEST_transmit(void)
{
    if (!allow_comms) { return; }
    GRN_TOGGLE();
    static const unsigned char TEST_MESSAGE[SMALL_RING_SIZE] = "NCSU  #1\r\n";
    unsigned char A1_tx_char = 0;
    if (!TEST_MESSAGE) { return; }


    while ((TEST_MESSAGE[A1_tx_char] != 0) && (A1_tx_char < sizeof(TEST_MESSAGE) - 1)) {
        IOT_2_PC[iot_rx_wr++] = TEST_MESSAGE[A1_tx_char++];
//        SEND_BUFFER[iot_rx_wr-1] = NULL;      // Null Proc_Buffer
        if (iot_rx_wr >= sizeof(IOT_2_PC)){
            iot_rx_wr = BEGINNING;
        }
    }
//    IOT_2_PC[A1_tx_char] = '\0';
//    //tx_index = BEGINNING;
//    iot_rx_wr = A1_tx_char;

    UCA1IE |= UCTXIE;
}


//void A1_TEST_transmit(void)
//{
//	static unsigned char TEST_MESSAGE[SMALL_RING_SIZE] = "NCSU  #1\r\n";
//	unsigned char A1_tx_char = 0;
//	if (!TEST_MESSAGE) { return; }
//
//	while ((TEST_MESSAGE[A1_tx_char] != 0) && (A1_tx_char < sizeof(IOT_2_PC) - 1)) {
//		IOT_2_PC[A1_tx_char] = TEST_MESSAGE[A1_tx_char++];
//	}
//	IOT_2_PC[A1_tx_char] = '\0';
//	//tx_index = BEGINNING;
//	iot_rx_wr = A1_tx_char;
//
//	UCA1IE |= UCTXIE;
//}


void Set_Baud_115200(void)
{
	UCA0IE &= ~UCTXIE;		// stop A0 TX interrupts during reconfig
	UCA1IE &= ~UCTXIE;		// stop A1 TX interrupts during reconfig

	UCA0CTLW0 |= UCSWRST;			// Put eUSCI in reset
	UCA1CTLW0 |= UCSWRST;			// Put eUSCI in reset

	UCA0BRW = 4;					// UCA0
	UCA0MCTLW = 0x5551;				// 115200 baud
	UCA1BRW = 4;					// UCA1
	UCA1MCTLW = 0x5551;				// 115200 baud

	UCA0IFG = 0;					// Clear eUSCI flags
	UCA1IFG = 0;					// Clear eUSCI flags

	UCA0CTLW0 &= ~UCSWRST;			// Release eUSCI from reset
	UCA1CTLW0 &= ~UCSWRST;			// Release eUSCI from reset

	UCA0IE |= UCRXIE;				// Re-enable RX interrupts
	UCA1IE |= UCRXIE;				// Re-enable RX interrupts

	BaudRate = BAUD_115200;
}

void Set_Baud_460800(void)
{
	UCA0IE &= ~UCTXIE;		// stop A0 TX interrupts during reconfig
	UCA1IE &= ~UCTXIE;		// stop A1 TX interrupts during reconfig

	UCA0CTLW0 |= UCSWRST;			// Put eUSCI in reset
	UCA1CTLW0 |= UCSWRST;			// Put eUSCI in reset

	UCA0BRW = 17;					// UCA0
	UCA0MCTLW = 0x4A00;				// 460,800 baud
	UCA1BRW = 17;					// UCA1
	UCA1MCTLW = 0x4A00;				// 460,800 baud

	UCA0IFG = 0;					// Clear eUSCI flags
	UCA1IFG = 0;					// Clear eUSCI flags

	UCA0CTLW0 &= ~UCSWRST;			// Release eUSCI from reset
	UCA1CTLW0 &= ~UCSWRST;			// Release eUSCI from reset

	UCA0IE |= UCRXIE;				// Re-enable RX interrupts
	UCA1IE |= UCRXIE;				// Re-enable RX interrupts

	BaudRate = BAUD_460800;

}


void Init_SerialComms(void) {
	Init_Serial_UCA0();
	Init_Serial_UCA1();
}


void Init_Serial_UCA0(void) 
{

	int i;
	for (i = 0; i < SMALL_RING_SIZE; i++) {
		USB_Char_Rx[i] = 0x00;
	}
	usb_rx_wr = BEGINNING;
	usb_rx_rd = BEGINNING;
	//for (i = 0; i < LARGE_RING_SIZE; i++) {		// May not use this
	//	USB_Char_Tx[i] = 0x00;						// USB Tx Buffer
	//}
	usb_tx_ring_wr = BEGINNING;
	usb_tx_ring_rd = BEGINNING;

	// Configure UART 0
	UCA0CTLW0 = 0;
	UCA0CTLW0 |=  UCSWRST;			// Put eUSCI in reset
	UCA0CTLW0 |=  UCSSEL__SMCLK;	// Set SMCLK as fBRCLK
	UCA0CTLW0 &= ~UCMSB;			// MSB, LSB select
	UCA0CTLW0 &= ~UCSPB;			// UCSPB = 0(1 stop bit) OR 1(2 stop bits)
	UCA0CTLW0 &= ~UCPEN;			// No Parity
	UCA0CTLW0 &= ~UCSYNC;
	UCA0CTLW0 &= ~UC7BIT;
	UCA0CTLW0 |=  UCMODE_0;

//	Baud Rate: 9600
//	1. Calculate N = fBRCLK / Baudrate
//		N = SMCLK / 9,600 => 8,000,000 / 9,600 = 833.3333333
//		If N > 16 continue with step 3, otherwise with step 2
//	2. OS16 = 0, UCBRx = INT(N)
//		Continue with step 4
//	3. OS16 = 1,
//		UCx		= INT(N/16),
//				= INT(N/16) = 833.333/16 => 52
//		UCFx	= INT([(N/16) � INT(N/16)] � 16)
//				= ([833.333 / 16 - INT(833.333 / 16)] * 16)
//				= (52.08333333 - 52) * 16
//				= 0.083 * 16 = 1
//	4. UCSx is found by looking up the fractional part of N (= N-INT(N)) in table Table 18-4
//		Decimal of SMCLK / 8,000,000 / 9,600 = 833.3333333 => 0.333 yields 0x49 [Table]
//	5. If OS16 = 0 was chosen, a detailed error calculation is recommended to be performed
// 
//																 TX error (%)	 RX error (%)
//		    BRCLK   Baudrate  UCOS16	UCBRx	UCFx	UCSx	 neg	 pos	 neg     pos
//		8,000,000       9600	    1	   52     1 	0x49	-0.08	 0.04	-0.10	 0.14
// 
//		8,000,000	  115200		1	    4     5	    0x55	-0.80	0.64	-1.12	1.76
//		8,000,000	  460800		0      17     0	    0x4A	-2.72	2.56	-3.76	7.28

	// UCA0MCTLW = UCSx concatenate UCFx concatenate UCOS16;
	// UCA0MCTLW = 0X55 concatenate    5 concatenate      1;
	// UCA0MCTLW = 0x4A concatenate    0 concatenate      0;

	UCA0BRW = 4;					// 115200 baud
	UCA0MCTLW = 0x5551;				// 115200 baud
	// UCA0BRW = 17;				// 460,800 baud
	// UCA0MCTLW = 0x4A00;			// 460,800 baud

	UCA0CTLW0 &= ~UCSWRST;			// release from reset
	//UCA0TXBUF = 0x00;				// Prime the Pump
	UCA0IE |= UCRXIE;				// Enable RX interrupt
}


void Init_Serial_UCA1(void) {
	//------------------------------------------------------------------------------
	//												 TX error (%)	 RX error (%)
	// BRCLK  Baudrate UCOS16  UCBRx  UCFx	 UCSx	  neg	 pos	  neg	 pos
	// 8000000	  4800		1    104     2	 0xD6	-0.08	0.04	-0.10	0.14
	// 8000000	  9600		1	  52     1	 0x49	-0.08	0.04	-0.10	0.14
	// 8000000	 19200		1	  26     0	 0xB6	-0.08	0.16	-0.28	0.20
	// 8000000	 57600		1	   8    10	 0xF7	-0.32	0.32	-1.00	0.36
	// 8000000	115200		1	   4     5	 0x55	-0.80	0.64	-1.12	1.76
	// 8000000	460800		0     17     0	 0x4A	-2.72	2.56	-3.76	7.28
	//------------------------------------------------------------------------------
	// Configure eUSCI_A0 for UART mode
	UCA1CTLW0 = 0;
	UCA1CTLW0 |=  UCSWRST;			// Put eUSCI in reset
	UCA1CTLW0 |=  UCSSEL__SMCLK;		// Set SMCLK as fBRCLK
	UCA1CTLW0 &= ~UCMSB;			// MSB, LSB select
	UCA1CTLW0 &= ~UCSPB;			// UCSPB = 0(1 stop bit) OR 1(2 stop bits)
	UCA1CTLW0 &= ~UCPEN;			// No Parity
	UCA1CTLW0 &= ~UCSYNC;
	UCA1CTLW0 &= ~UC7BIT;
	UCA1CTLW0 |=  UCMODE_0;
	//   BRCLK  Baudrate   UCOS16    UCBRx    UCFx    UCSx     neg    pos     neg    pos
	// 8000000    115200      1        4        5     0x55   -0.80   0.64   -1.12   1.76
	// UCA?MCTLW = UCSx + UCFx + UCOS16
	UCA1BRW = 4;					// 115,200 baud
	UCA1MCTLW = 0x5551;

	UCA1CTLW0 &= ~UCSWRST;			// release from reset
	//UCA0TXBUF = 0x00;				// Prime the Pump
	UCA1IE |= UCRXIE;				// Enable RX interrupt
	//------------------------------------------------------------------------------
}


