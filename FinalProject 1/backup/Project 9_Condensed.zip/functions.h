//******************************************************************************
//
//  Description: This file contains the Function prototypes
//
//  Created by: Jim Carlson
//  Aug 2013
// 
//  Modified for use by: Dallas Owens
//  9/2025
//  Built with IAR Embedded Workbench Version: V4.10A/W32 (5.40.1)
//******************************************************************************

#include <stdbool.h>

// PROVIDE GLOBALS ___________________
extern volatile char slow_input_down;
extern char display_line[4][11];
extern char *display[4];
extern unsigned char display_mode;
extern volatile unsigned char display_changed;
extern volatile unsigned char update_display;
extern volatile unsigned int update_display_count;
extern volatile unsigned int Time_Sequence;
extern volatile char one_time;
extern unsigned int test_value;
extern char chosen_direction;
extern char change;
extern unsigned int wheel_move;
extern char forward;
//____________________________________


//  ------------
// | MY GLOBALS |
//  ------------

// INTITALIZAION VARIABLES ____________
extern volatile unsigned char iot_boot;


// Project 4______________
extern unsigned char state;
extern unsigned char step;
extern volatile unsigned int time_change;

// Project 6______________
extern char adc_char[4];


// PROVIDE Functions ___________________
// Main
void main(void);

// Initialization
void Init_Conditions(void);

// Interrupts
void enable_interrupts(void);
//__interrupt void Timer0_B0_ISR(void);
//__interrupt void switch_interrupt(void);

__interrupt void switchP2_interrupt(void);
__interrupt void switchP4_interrupt(void);

__interrupt void TIMER_B0_CCR0_ISR(void);
__interrupt void TIMER_BO_CCR1_2_0V_ISR(void);

__interrupt void TIMER_B1_CCR0_ISR(void);
__interrupt void TIMER_B1_CCR1_2_0V_ISR(void);

__interrupt void ADC_ISR(void);



// Analog to Digital Converter

// Clocks
void Init_Clocks(void);

// LED Configurations
void Init_LEDs(void);
void IR_LED_control(char selection);
void Backlite_control(char selection);

  // LCD
void Display_Process(void);
void Display_Update(char p_L1,char p_L2,char p_L3,char p_L4);
void enable_display_update(void);
void update_string(char *string_data, int string);
void Init_LCD(void);
void lcd_clear(void);
void lcd_putc(char c);
void lcd_puts(char *s);

void lcd_power_on(void);
void lcd_write_line1(void);
void lcd_write_line2(void);
//void lcd_draw_time_page(void);
//void lcd_power_off(void);
void lcd_enter_sleep(void);
void lcd_exit_sleep(void);
//void lcd_write(unsigned char c);
//void out_lcd(unsigned char c);

void Write_LCD_Ins(char instruction);
void Write_LCD_Data(char data);
void ClrDisplay(void);
void ClrDisplay_Buffer_0(void);
void ClrDisplay_Buffer_1(void);
void ClrDisplay_Buffer_2(void);
void ClrDisplay_Buffer_3(void);

void SetPostion(char pos);
void DisplayOnOff(char data);
void lcd_BIG_mid(void);
void lcd_BIG_bot(void);
void lcd_120(void);

void lcd_4line(void);
void lcd_out(char *s, char line, char position);
void lcd_rotate(char view);

//void lcd_write(char data, char command);
void lcd_write(unsigned char c);
void lcd_write_line1(void);
void lcd_write_line2(void);
void lcd_write_line3(void);

void lcd_command( char data);
void LCD_test(void);
void LCD_iot_meassage_print(int nema_index);

// Menu
void Menu_Process(void);

// Ports
void Init_Ports(void);
void Init_Port1(void);
void Init_Port2(void);
void Init_Port3(char SMCLK_SETTING);
// void Init_Port3(void);
void Init_Port4(void);
void Init_Port5(void);
void Init_Port6(void);

// SPI
void Init_SPI_B1(void);
void SPI_B1_write(char byte);
void spi_rs_data(void);
void spi_rs_command(void);
void spi_LCD_idle(void);
void spi_LCD_active(void);
void SPI_test(void);
void WriteIns(char instruction);
void WriteData(char data);

// Switches
void Init_Switches(void);
void switch_control(void);
void enable_switch_SW1(void);
void enable_switch_SW2(void);
void disable_switch_SW1(void);
void disable_switch_SW2(void);
void Switches_Process(void);
void Init_Switch(void);
void Switch_Process(void);
void Switch1_Process(void);
void Switch2_Process(void);
void menu_act(void);
void menu_select(void);

// Timers
void Init_Timers(void);
void Init_Timer_B0(void);
void Init_Timer_B1(void);
void Init_Timer_B2(void);
void Init_Timer_B3(void);

void usleep(unsigned int usec);
void usleep10(unsigned int usec);
void five_msec_sleep(unsigned int msec);
void measure_delay(void);
void out_control_words(void);


// State Machine ________________________

// void Carlson_StateMachine(void);

//void Shape_StateMachine(void);
//void Init_Shape_Machine(void);
//
//void Run_STRAIGHT(void);
//void Run_CIRCLE(void);
//void Run_FIGURE8(void);
//void Run_TRIANGLE(void);
//


//
//void run_case_STRAIGHT(void);
//void run_case_CIRCLE(void);
//void run_case_FIGURE8(void);
//void run_case_TRIANGLE(void);
//bool Triangle_Straight(void);
//bool Triangle_Turn(void);
//

// MOVEMENT STATES______________________
void idle_case(void);
void wait_case(void);
void set_case(void);
void seek_case(void);
void found_Case(void);
void align_case(void);
void nudge_case(void);
void stop_case(void);

void brake_case(void);
void brake_to(unsigned char nextState);

void ebrake_case(void);
void ebrake_to(unsigned char newState);

bool Quick_Pause(void);
bool Pause_For(unsigned int pause);
void Safe_Stop(void);

// Project 5 -------------------
void run_case_Movement(void);
void Project5_StateMachine(void);
void Init_Project5(void);

// Project 6 --------------------
void Project6_StateMachine(void);
void Init_Project6(void);


// WHEELS
//void Wheels_Straight_control(void);
void Wheels_Motors_off(void);
void Wheels_Forward_On(void);
void Wheels_Reverse_On(void);

void Wheels_Right_Forward(void);
void Wheels_Right_Reverse(void);
void Wheels_Right_Off(void);

void Wheels_Left_Forward(void);
void Wheels_Left_Reverse(void);
void Wheels_Left_Off(void);

void Wheels_Spin_Right(void);       // CW
void Wheels_Spin_Left(void);        // CCW

// PWM
void Init_PWM(void);
void PWM_Stop(void);
void PWM_Move(void);

void PWM_FORWARD(void);
void PWM_FORWARD_BRAKING(void);
void PWM_FULLSTOP(void);
void PWM_TURN_RIGHT(void);
void PWM_TURN_LEFT(void);
void PWM_ALIGN_RIGHT(void);
void PWM_ALIGN_LEFT(void);
void PWM_NUDGE_RIGHT(void);
void PWM_NUDGE_LEFT(void);


// DISPLAY
//void Display_Shape(void);
void Display_State(void);

//void set_display(const char *text);
void set_display(const char* text, unsigned char line);
void set_display_line4(const char *text);
void display_default(void);

void Display_SMCLK_Setting(void);

void display_black_line_detected(void);
void display_detect_values(void);
void display_detect_difference(void);

void Display_Baud(void);

void display_song(unsigned int idx, char* str);
void display_banner(unsigned char line, unsigned int idx, const char* str);


// MY TIMERS







// ADC
void Init_ADC(void);
void HEXtoBCD(int hex_value);
void adc_line(char line, char location);
void Reset_ADC(void);
unsigned char DirectionChange(void);


// CALIBRATION FUNCTIONS
void Calibration_Process(void);


// SERIAL COMMUNICATIONS - UART
void Init_SerialComms(void);
void Init_Serial_UCA0(void);
void Init_Serial_UCA1(void);

void Update_Baud_Rate(void);
void Display_Baud(void);
void display_rx(char line, char location);

void UART_Process(void);
void A1_transmit(const char SEND_BUFFER[]);
void A0_transmit(void);
void Set_Baud_115200(void);
void Set_Baud_460800(void);

void Init_IOT(void);
void IOT_Process(void);

void A1_TEST_transmit(void);



// MENU FUNCTIONS
void Main_Menu(void);
void Resistor_Menu(void);
void Shape_Menu(void);
void Song_Menu(void);















