/*
 * Display.c
 *
 *  Created on: Sep 9, 2025
 *      Author: Dallas.Owens
 */

#include  "msp430.h"
#include  "macros.h"
#include  "functions.h"
#include  "ports.h"
#include  "timers.h"
#include  "switches.h"
#include  "LCD.h"
#include  "states.h"
#include  "UART.h"
#include  <string.h>

extern unsigned char SMCLK_SETTING;
extern unsigned char state;
extern unsigned char step;

extern volatile unsigned char SW1_display,  SW2_display;
extern volatile unsigned char default_display;

extern volatile unsigned int ADC_Thumb;
extern volatile unsigned int ADC_Left_Detect;
extern volatile unsigned int ADC_Right_Detect;
extern volatile unsigned char ADC_Channel;

extern volatile unsigned char display_thumb;
extern volatile unsigned char display_left_detect;
extern volatile unsigned char display_right_detect;
extern volatile unsigned char display_changed;

extern unsigned char drive_enabled;
extern unsigned char display_ADC_values;

extern unsigned char BaudRate;


// _____________ DISPLAY GOVERNING FUNCTION _____________________
// if (update_display) {
//    update_display = 0;
//    if (display_changed) {
//        display_changed = 0;
//        Display_Update(0, 0, 0, 0);
//    }
//}
// ___________________________________________________________


void Display_Process(void)
{
    if (update_display)
    { // Update display if ready
        update_display = 0;
        if (display_changed) {
            display_changed = 0;
            Display_Update(0, 0, 0, 0);
        }
    }
}


// *********** DISPLAY FUNCTIONS ********************
// _____ Homework 9 ________________
void display_song(unsigned int idx, char* str) {
    unsigned int i;
    for (i = 0; i < 10; i++) {
		display_line[2][i] = str[idx + i];
		if (str[i] == '\0') {
			break;
		}
    }
	display_changed = TRUE;
}


void display_banner(unsigned char line, unsigned int idx, const char* str) 
{
    display_line[line][0] = display_line[line][1];
	display_line[line][1] = display_line[line][2];
	display_line[line][2] = display_line[line][3];
	display_line[line][3] = display_line[line][4];
	display_line[line][4] = display_line[line][5];
	display_line[line][5] = display_line[line][6];
	display_line[line][6] = display_line[line][7];
	display_line[line][7] = display_line[line][8];
	display_line[line][8] = display_line[line][9];
	display_line[line][9] = str[idx];
	display_line[line][10] = '\0';
	display_changed = TRUE;
}


// _____ Homework 8 __________________
void Display_Baud(void) 
{
    strcpy(display_line[0], "          ");
    strcpy(display_line[1], "         ");
    strcpy(display_line[2], "   Baud   ");

    switch (BaudRate) {
	case BAUD_115200:
		strcpy(display_line[3], "  115200  ");
		break;

	case BAUD_460800:
		strcpy(display_line[3], "  460800  ");
		break;

	default:
		strcpy(display_line[3], "  ERROR   ");
		break;
    }
	display_changed = TRUE;
}


//_____ Project 6 ____________________
void Display_Process_Project6(void)
{ // Check if new ADC results
    if(drive_enabled) {
        Display_State();
    }
    // Testing
//    if (display_thumb) {
//        display_thumb = FALSE;
//        HEXtoBCD(ADC_Thumb);
//        adc_line(2, 6);
//        display_changed = TRUE;
//    }
//    if (display_left_detect) {
//        display_left_detect = FALSE;
//        HEXtoBCD(ADC_Left_Detect);                  // Convert to BCD for display
//        adc_line(4, 0);                             // Display on line 4 - LEFT side
//        display_changed = TRUE;
//    }
//    if (display_right_detect) {
//        display_right_detect = FALSE;
//        HEXtoBCD(ADC_Right_Detect);
//        adc_line(4, 6);                             // Display on line 4 - RIGHT side
//        display_changed = TRUE;
//    }
    if(display_ADC_values) {

        if (display_thumb) {
            display_thumb = FALSE;
            HEXtoBCD(ADC_Thumb);
            adc_line(2, 6);
            display_changed = TRUE;
        }
        if (display_left_detect) {
            display_left_detect = FALSE;
            HEXtoBCD(ADC_Left_Detect);                  // Convert to BCD for display
            adc_line(4, 0);                             // Display on line 4 - LEFT side
            display_changed = TRUE;
        }
        if (display_right_detect) {
            display_right_detect = FALSE;
            HEXtoBCD(ADC_Right_Detect);
            adc_line(4, 6);                             // Display on line 4 - RIGHT side
            display_changed = TRUE;
        }
    }
    if (update_display)
    { // Update display if ready
        update_display = 0;
        if (display_changed) {
            display_changed = 0;
            Display_Update(0, 0, 0, 0);
        }
    }
}

void Display_State(void) {
    strcpy(display_line[0], "STATE:    ");   // line 3
    switch (state) {
    case IDLE:
        strcpy(display_line[1], "      IDLE");
        break;
    case WAIT:
        strcpy(display_line[1], "      WAIT");
        break;
    case SET:
        strcpy(display_line[1], "      SET ");
        break;
    case SEEK:
        display_detect_difference();
        strcpy(display_line[1], "      SEEK");
        break;
    case FOUND:
        display_black_line_detected();
        strcpy(display_line[1], "     FOUND");
        break;
    case ALIGN:
        display_detect_difference();
        strcpy(display_line[1], "     ALIGN");
        break;
	case NUDGE:
		strcpy(display_line[1], "     NUDGE");
		break;
    case BRAKE:
        strcpy(display_line[1], "     BRAKE");
        break;
    case STOP:
        display_detect_values();
        strcpy(display_line[1], "      STOP");
        break;
    default:
        strcpy(display_line[1], "    NONE??");
        break;
    }

    display_changed = TRUE;
            //lcd_BIG_mid();
}

//_____ BLACK LINE HELPERS ____________

void display_black_line_detected(void) {
    strcpy(display_line[2], "Black Line");
    strcpy(display_line[3], " Detected ");
    display_changed = TRUE;
}

void display_detect_values(void) {    // Display both sensor values when over black line
    HEXtoBCD(ADC_Left_Detect);
    adc_line(2, 0);  // Left value on line 2, left side

    HEXtoBCD(ADC_Right_Detect);
    adc_line(2, 6);  // Right value on line 2, right side

    strcpy(display_line[3], "  ONLINE  ");
    display_changed = TRUE;
}

void display_detect_difference(void) {    // Show which sensor is detecting stronger signal
    int difference = (int)ADC_Left_Detect - (int)ADC_Right_Detect;

    if (difference > HORSE_GRENADES) {
        strcpy(display_line[3], "LeftStrong");
    } else if (difference < -HORSE_GRENADES) {
        strcpy(display_line[3], "RightStrng");
    } else {
        strcpy(display_line[3], " CENTERED ");
    }
    display_changed = TRUE;
}



//_____ HEX DISPLAY HELPERS ____________
void display_hex(char hex[4]) {                  // "---3456---"
	//strcpy(display_line[3], "  ADC VAL ");
    display_line[3][3] = hex[0];                 
    display_line[3][4] = hex[1];
    display_line[3][5] = hex[2];
    display_line[3][6] = hex[3];
	display_changed = TRUE;
}

void display_emitter(void){
    strcpy(display_line[0], "IR:       ");

}

void display_default(void) {
    strcpy(display_line[0], "IR:    ON ");
    strcpy(display_line[1], "THUMB:    ");
    strcpy(display_line[2], "LEFT RIGHT");
    strcpy(display_line[3], "          ");
    display_changed = TRUE;
}


// ____________________ GENERIC DISPLAY HELPERS _______________________
//void set_display(const char* text) {
//    if (strlen(text) > 10) {
//        strcpy(display_line[1], "TXT 2 LONG");
//    }
//    else {
//        strcpy(display_line[1], text);
//        display_line[1][10] = '\0';         // Weirdness possibly due to no termination of string?
//    }
//    display_changed = TRUE;
//}

void set_display(const char* text, unsigned char line) {
    if (strlen(text) > 10) {
        strcpy(display_line[1], "TXT 2 LONG");
    }
    else {
        strcpy(display_line[line], text);
        display_line[line][10] = '\0';         // Weirdness possibly due to no termination of string?
    }
    display_changed = TRUE;
}

void set_display_line4(const char* text) {
    if (strlen(text) > 10) {
        strcpy(display_line[3], "TXT 2 LONG");
    }
    else {
        strcpy(display_line[1], text);
        display_line[3][10] = '\0';         // Weirdness possibly due to no termination of string?
    }
    display_changed = TRUE;
}


//void display_default(void){
//    strcpy(display_line[0], "  NEW CAR ");
//    strcpy(display_line[1], "  WHO DIS ");
//    strcpy(display_line[2], "SirCutSpun");
//    strcpy(display_line[3], "<--PRESS--");
//    display_changed = TRUE;
//}







//_____ Project 5 ___________________________
void Display_Project5(void){
    if (default_display){
        default_display = 0;
        strcpy(display_line[3], "<- Press->");
        display_changed = TRUE;
    }
    if (SW1_display && SW2_display) {
        SW1_display = 0;
        SW2_display = 0;
        strcpy(display_line[3], "SW1 && SW2");
        display_changed = TRUE;
    }
    if (SW1_display) {
        SW1_display = 0;
        strcpy(display_line[3], "<-Switch 1");
        display_changed = TRUE;
    }
    if (SW2_display){
        SW2_display = 0;
        strcpy(display_line[3], "Switch 2->");
        display_changed = TRUE;
    }

    if (update_display)
    {
        update_display = 0;
        if (display_changed){
            display_changed = 0;
            Display_Update(0, 0, 0, 0);
        }
    }
}

void Display_SMCLK_Setting(void){
    switch(SMCLK_SETTING)
    {
    case USE_GPIO:
        strcpy(display_line[0], "Mode:     ");
        strcpy(display_line[1], "     GPIO ");
        break;

    case USE_SMCLK:
        strcpy(display_line[0], "Mode:     ");
        strcpy(display_line[1], "     SMCLK");
        break;
    }
    display_changed = TRUE;
}


//void Display_Shape(void){
//    switch(shapes){
//    case STRAIGHT:
//        strcpy(display_line[0], "   SHAPE  ");
//        strcpy(display_line[1], " STRAIGHT ");
//        break;
//    case CIRCLE:
//        strcpy(display_line[0], "   SHAPE  ");
//        strcpy(display_line[1], "  CIRCLE  ");
//        break;
//    case FIGURE8:
//        strcpy(display_line[0], "   SHAPE  ");
//        strcpy(display_line[1], " FIGURE-8 ");
//        break;
//    case TRIANGLE:
//        strcpy(display_line[0], "   SHAPE  ");
//        strcpy(display_line[1], " TRIANGLE ");
//        break;
//    default:
//        strcpy(display_line[0], "   SHAPE  ");
//        strcpy(display_line[1], "  (NONE)  ");
//        break;
//    }
//    //lcd_BIG_mid();
//    display_changed = TRUE;
//}








