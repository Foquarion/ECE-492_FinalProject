/*
 * switches.h
 *
 *  Created on: Sep 21, 2025
 *      Author: Dallas.Owens
 */

#ifndef SWITCHES_H_
#define SWITCHES_H_

#define DEBOUNCE_TIME       (5)
#define DEBOUNCE_RESTART    (0)
#define PRESSED             (0)
#define RELEASED            (1)
#define OKAY                (1)
#define NOT_OKAY            (0)


// Globals
//extern unsigned int cycle_time;
//extern unsigned int event;



#endif /* SWITCHES_H_ */
