//------------------------------------------------------------------------------
//
//  Description: This file contains the Main Routine - "While" Operating System
//
//  Jim Carlson
//  Jan 2023
//  Built with Code Composer Version: CCS12.4.0.00007_win64
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
#include  "msp430.h"
#include  "macros.h"
#include  "functions.h"
#include  "ports.h"
#include  "timers.h"
#include  "switches.h"
#include  "LCD.h"
#include  "states.h"
#include  <string.h>
//#include "StateMachine.h"
//#include "shapes.h"


// Global Variables
volatile char slow_input_down;
extern char display_line[4][11];
extern char *display[4];
unsigned char display_mode;
extern volatile unsigned char display_changed;
extern volatile unsigned char update_display;
extern volatile unsigned int update_display_count;
extern volatile unsigned int Time_Sequence;
extern volatile char one_time;


// ************ MY VARIABLES *******************
unsigned int old_Time_Sequence;     // Track if time sequence has changed
//(functions.h) extern volatile unsigned int time_change;           // identifier that change has occurred

extern unsigned int SW1_pressed;
extern unsigned int SW2_pressed;


extern volatile unsigned char IOT_2_PC[SMALL_RING_SIZE];
extern volatile unsigned char send_message;
extern volatile unsigned char allow_comms;          // Prevent communications until first char received from PC


// *********************************************


void main(void) {
    //    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    PM5CTL0 &= ~LOCKLPM5;
    // Disable the GPIO power-on default high-impedance mode to activate
    // previously configured port settings

    // ______________ PROGRAM INITIALIZATION FUNCTIONS ____________________________________
    Init_Ports();                        // Initialize Ports
    Init_Clocks();                       // Initialize Clock System
    Init_Conditions();                   // Initialize Variables and Initial Conditions
    Init_Timers();                       // Initialize Timers
    Init_LCD();                          // Initialize LCD
    Init_SerialComms();                  // Initialize Serial Communications

    strcpy(display_line[0], "  NEW CAR ");
    strcpy(display_line[1], "  WHO DIS ");
    strcpy(display_line[2], " BaudRate ");
    strcpy(display_line[3], "  SPLASH  ");
    display_changed = TRUE;


    // ___________________ PROJECT SPECIFIC SETUP __________________________________

    RED_OFF();
    GRN_OFF();

    __enable_interrupt();


    //------------------------------------------------------------------------------
    // Begining of the "While" Operating System
    //------------------------------------------------------------------------------
    while (ALWAYS) {
        //		if (iot_boot) {                    // ALT: Create IOT RESET function that enables interrupt / EN LOW for boot delay duration
        //			iot_boot = 0;                  //       Call once during a Boot-Up Delay routine BEFORE While (always)
        //            Init_IOT();
        //		}
        Switches_Process();                // Check for switch state change
        Display_Process();                 // Update Display
        //UART_Process();

        if (!allow_comms) {
            strcpy(display_line[3], "Comms: OFF");
        }
        if (allow_comms) {
            strcpy(display_line[3], "Comms: ON ");
        }
        display_changed = 1;

        // IoT TESTING PROCESSES
        if (send_message) {
            send_message = 0;
            A1_TEST_transmit();
        }
    }
}

